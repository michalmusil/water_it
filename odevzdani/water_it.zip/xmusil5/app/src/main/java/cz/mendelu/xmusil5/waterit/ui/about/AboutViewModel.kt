package cz.mendelu.xmusil5.waterit.ui.about

import androidx.lifecycle.ViewModel

class AboutViewModel(): ViewModel() {
}